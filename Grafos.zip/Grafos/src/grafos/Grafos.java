
package grafos;

import java.util.*;
/**
 *
 * @author Nery Contreras
 */
public class Grafos {

    private Map<Ciudad, List<Ciudad>> adj;
    private Map<String, Integer> dist;
    private List<Ciudad> ciu;

    public Grafos() {
        adj = new HashMap<>();
        dist = new HashMap<>();
        ciu = new ArrayList<>();
    }

    public void agregarCiudad(Ciudad c) {
        adj.putIfAbsent(c, new ArrayList<>());
        ciu.add(c);
    }

    public void agregarRuta(Ciudad o, Ciudad d, int dis) {
        adj.get(o).add(d);
        adj.get(d).add(o);
        dist.put(o.nombre + "-" + d.nombre, dis);
        dist.put(d.nombre + "-" + o.nombre, dis);
    }

    public void mostrarGrafo() {
        adj.forEach((c, l) -> System.out.println(c + " -> " + l));
    }

      public void floydWarshall() {
        Map<Ciudad, Map<Ciudad, Integer>> rutas = new HashMap<>();

        ciu.forEach(c -> {
            rutas.put(c, new HashMap<>());
            ciu.forEach(o -> {
                if (!c.equals(o))
                    rutas.get(c).put(o, dist.getOrDefault(c.nombre + "-" + o.nombre, Integer.MAX_VALUE));
            });
        });

        for (Ciudad k : ciu)
            for (Ciudad i : ciu)
                for (Ciudad j : ciu)
                    if (!i.equals(j) && rutas.get(i).containsKey(k) && rutas.get(k).containsKey(j)) {
                        int nDis = rutas.get(i).get(k) + rutas.get(k).get(j);
                        if (rutas.get(i).get(k) != Integer.MAX_VALUE && rutas.get(k).get(j) != Integer.MAX_VALUE && 
                            (!rutas.get(i).containsKey(j) || nDis < rutas.get(i).get(j))) {
                            rutas.get(i).put(j, nDis);
                        }
                    }

        System.out.println("Rutas mas cortas entre todas las ciudades (Floyd-Warshall):");
        rutas.forEach((o, m) -> m.forEach((d, dis) -> 
            System.out.println("De " + o + " a " + d + " -> " +
                (dis == Integer.MAX_VALUE || dis < 0 ? "No hay ruta" : dis))));
    }

    public void dijkstra(Ciudad ini) {
        Map<Ciudad, Integer> dMin = new HashMap<>();
        Map<Ciudad, Ciudad> pred = new HashMap<>();
        PriorityQueue<Ciudad> cola = new PriorityQueue<>(Comparator.comparingInt(dMin::get));

        adj.keySet().forEach(c -> {
            dMin.put(c, Integer.MAX_VALUE);
            pred.put(c, null);
        });
        dMin.put(ini, 0);
        cola.add(ini);

        while (!cola.isEmpty()) {
            Ciudad act = cola.poll();
            for (Ciudad vec : adj.get(act)) {
                int nDis = dMin.get(act) + dist.getOrDefault(act.nombre + "-" + vec.nombre, Integer.MAX_VALUE);
                if (nDis < dMin.get(vec)) {
                    dMin.put(vec, nDis);
                    pred.put(vec, act);
                    cola.add(vec);
                }
            }
        }

        System.out.println("Rutas mas cortas desde " + ini + ":");
        dMin.forEach((dest, dis) -> {
            if (!dest.equals(ini)) {
                if (dis == Integer.MAX_VALUE) {
                    System.out.println("Hasta " + dest + " -> No hay ruta");
                } else {
                    List<Ciudad> ruta = new ArrayList<>();
                    for (Ciudad at = dest; at != null; at = pred.get(at)) ruta.add(at);
                    Collections.reverse(ruta);
                    System.out.println("Hasta " + dest + " -> " + ruta + " | Distancia: " + dis);
                }
            }
        });
    }

    /**
     *  TSP (Held-Karp) Ricky Nuque
     * 
     */
   public void travelingSalesmanPD(Ciudad ini, Ciudad fin) {
    int n = ciu.size();
    if (n <= 1) {
        System.out.println("No hay suficientes ciudades para TSP.");
        return;
    }

    Map<Ciudad, Integer> idx = new HashMap<>();
    for (int i = 0; i < n; i++) {
        idx.put(ciu.get(i), i);
    }

    int startIndex = idx.get(ini);
    int endIndex = idx.get(fin);
    int[][] cost = new int[n][n];
    final int INF = 1000000000;

    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            if (i == j) {
                cost[i][j] = 0;
            } else {
                String key = ciu.get(i).nombre + "-" + ciu.get(j).nombre;
                cost[i][j] = dist.getOrDefault(key, INF);
            }
        }
    }

    int[][] dp = new int[1 << n][n];
    for (int[] row : dp) {
        Arrays.fill(row, INF);
    }

    int[][] parent = new int[1 << n][n];
    for (int[] row : parent) {
        Arrays.fill(row, -1);
    }

    dp[1 << startIndex][startIndex] = 0;

    for (int mask = 0; mask < (1 << n); mask++) {
        for (int i = 0; i < n; i++) {
            if ((mask & (1 << i)) == 0) continue;
            if (dp[mask][i] == INF) continue;

            for (int j = 0; j < n; j++) {
                if ((mask & (1 << j)) == 0) {
                    int nextMask = mask | (1 << j);
                    int newCost = dp[mask][i] + cost[i][j];
                    if (newCost < dp[nextMask][j]) {
                        dp[nextMask][j] = newCost;
                        parent[nextMask][j] = i;
                    }
                }
            }
        }
    }

    int allVisitedMask = (1 << n) - 1;
    int res = dp[allVisitedMask][endIndex];
    if (res == INF) {
        System.out.println("No se encontro una ruta TSP valida.");
        return;
    }

    List<Integer> path = new ArrayList<>();
    int mask = allVisitedMask;
    int cur = endIndex;

    // Reconstrucción del camino sin agregar de más el nodo inicial
    while (cur != -1) {
        path.add(cur);
        int tmp = parent[mask][cur];
        mask = mask & ~(1 << cur);
        cur = tmp;
    }

    Collections.reverse(path);

    List<Ciudad> rutaCiudades = new ArrayList<>();
    for (int index : path) {
        rutaCiudades.add(ciu.get(index));
    }

    System.out.println("\n--- TSP (Held-Karp) ---");
    System.out.println("Ruta óptima en orden de visita: " + rutaCiudades);
    System.out.println("Costo total de la ruta (distancia): " + res);
}

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Grafos g = new Grafos();

        System.out.print("Ingrese el numero de ciudades: ");
        int nC = sc.nextInt(); sc.nextLine();

        Map<String, Ciudad> cMap = new HashMap<>();

        for (int i = 0; i < nC; i++) {
            System.out.print("Ingrese el nombre de la ciudad " + (i + 1) + ": ");
            String nom = sc.nextLine();
            Ciudad c = new Ciudad(nom);
            cMap.put(nom, c);
            g.agregarCiudad(c);
        }

        System.out.print("Ingrese el numero de rutas: ");
        int nR = sc.nextInt(); sc.nextLine();

        for (int i = 0; i < nR; i++) {
            System.out.println(" ");
            System.out.print("Ingrese la ciudad de origen: ");
            String o = sc.nextLine();
            System.out.print("Ingrese la ciudad de destino: ");
            String d = sc.nextLine();
            System.out.print("Ingrese la distancia entre " + o + " y " + d + ": ");
            int dis = sc.nextInt(); sc.nextLine();

            g.agregarRuta(cMap.get(o), cMap.get(d), dis);
        }

        g.mostrarGrafo();
        System.out.println(" ");
        System.out.print("Ingrese la ciudad de inicio para Dijkstra: ");
        String ini = sc.nextLine();
        g.dijkstra(cMap.get(ini));

        System.out.println(" ");
        g.floydWarshall();

        System.out.println("");
        System.out.print("Ingrese la ciudad de inicio para TSP: ");
        String iniTSP = sc.nextLine();
        System.out.print("Ingrese la ciudad de fin para TSP: ");
        String finTSP = sc.nextLine();

        g.travelingSalesmanPD(cMap.get(iniTSP), cMap.get(finTSP));

        sc.close();
    }
}
